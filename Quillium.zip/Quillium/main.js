var counter = 1;
setInterval(function(){
    document.getElementById('radio' + counter).checked = true;
    counter++;
    if(counter > 4){
        counter = 1;
    }
}, 4000); 


document.addEventListener("DOMContentLoaded", function () {
var scrollLinks = document.querySelectorAll('.scroll-to');

scrollLinks.forEach(function (link) {
link.addEventListener('click', function (e) {
e.preventDefault();

var targetId = this.getAttribute('href').substring(1);
var targetElement = document.getElementById(targetId);

window.scrollTo({
  top: targetElement.offsetTop,
  behavior: 'smooth'
});
});
});
});
